﻿// Практическая работа №2. Многопоточное считывание и обработка файла.
// Задание 1: подсчет гласных букв (a e i o u) в большом файле несколькими потоками.
// Задание 2: сумма элементов массива из 100 чисел в 4 потоках.
// Условие: внутри потоков НЕТ оператора if - только циклы и арифметика.
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

namespace Pr2_Threads
{
    // Рабочий объект одного потока: читает свою часть файла и считает гласные
    class VowelWorker
    {
        private readonly string _path;
        private readonly long _start;    // с какого байта читать
        private readonly long _length;   // сколько байт читать

        public long Count;               // результат этого потока (его читает основной поток)
        public Exception Error;          // ошибка внутри потока (если произошла)

        public VowelWorker(string path, long start, long length)
        {
            _path = path;
            _start = start;
            _length = length;
        }

        // Тело потока. Здесь нет if: условия заменены циклами, таблицей и арифметикой.
        public void Run()
        {
            try
            {
                byte[] buffer = new byte[64 * 1024];
                long count = 0;
                long remaining = _length;
                int read = 1;

                using (FileStream fs = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    fs.Seek(_start, SeekOrigin.Begin);

                    // читаем, пока есть что читать
                    while (remaining > 0 && read > 0)
                    {
                        // Math.Min вместо if: не читаем больше, чем осталось в нашей части
                        read = fs.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));

                        for (int i = 0; i < read; i++)
                        {
                            // VowelTable[байт] равно 1 для гласной и 0 для остальных:
                            // вместо "if (гласная) count++" просто прибавляем 0 или 1
                            count += Program.VowelTable[buffer[i]];
                        }
                        remaining -= read;
                    }
                }

                Count = count;

                // Общий итог - ресурс, общий для всех потоков, поэтому обновляем его атомарно
                Interlocked.Add(ref Program.Total, count);
            }
            catch (Exception ex)
            {
                Error = ex;
            }
        }
    }

    class Program
    {
        // Таблица из 256 значений: для каждого возможного байта - 1, если это a, e, i, o, u (любой регистр)
        public static readonly int[] VowelTable = BuildTable();

        // Общий итог по всем потокам (меняется через Interlocked.Add)
        public static long Total;

        static int[] BuildTable()
        {
            int[] table = new int[256];
            foreach (char c in "aeiouAEIOU")
            {
                table[c] = 1;
            }
            return table;
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            string path = args.Length > 0 ? args[0] : "large_text.txt";
            int partsCount = 4;

            Console.WriteLine("=== ЗАДАНИЕ 1: подсчет гласных в файле " + path + " ===");
            Task1(path, partsCount);

            Console.WriteLine();
            Console.WriteLine("=== ЗАДАНИЕ 2: сумма массива из 100 чисел в 4 потоках ===");
            Task2();

            Console.WriteLine();
            Console.WriteLine("Нажмите Enter для выхода...");
            Console.ReadLine();
        }

        // ------------------------------ ЗАДАНИЕ 1 ------------------------------
        static void Task1(string path, int n)
        {
            if (!File.Exists(path))
            {
                Console.WriteLine("Файл не найден, создаю тестовый файл (около 30 МБ)...");
                GenerateFile(path, 30L * 1024 * 1024);
            }

            long fileLength = new FileInfo(path).Length;
            long part = fileLength / n;          // размер каждой части
            long rest = fileLength - part * n;   // остаток, если размер не делится на n нацело
            Console.WriteLine("Размер файла: " + fileLength + " байт, потоков: " + n + ", часть: " + part + " байт");

            VowelWorker[] workers = new VowelWorker[n];
            Thread[] threads = new Thread[n];
            int started = 0;
            Total = 0;

            Stopwatch sw = Stopwatch.StartNew();
            try
            {
                // 1) создаем рабочие объекты и потоки
                for (int i = 0; i < n; i++)
                {
                    long length = part + (i == n - 1 ? rest : 0);   // последняя часть забирает остаток
                    workers[i] = new VowelWorker(path, part * i, length);
                    threads[i] = new Thread(workers[i].Run);
                    threads[i].Name = "Reader-" + (i + 1);
                }

                // 2) запускаем все потоки
                for (int i = 0; i < n; i++)
                {
                    threads[i].Start();
                    started++;
                }
            }
            catch (OutOfMemoryException ex)
            {
                Console.WriteLine("Не хватает памяти для создания потока: " + ex.Message);
            }
            catch (ThreadStateException ex)
            {
                Console.WriteLine("Поток нельзя запустить в текущем состоянии: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании или запуске потоков: " + ex.Message);
            }

            // 3) основной поток ждет завершения всех запущенных потоков
            for (int i = 0; i < started; i++)
            {
                threads[i].Join();
            }
            sw.Stop();

            if (started != n)
            {
                Console.WriteLine("Запущено потоков: " + started + " из " + n + ". Итог не может быть верным.");
                return;
            }

            // 4) собираем результаты
            long sum = 0;
            bool hasErrors = false;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Поток " + (i + 1) + ": гласных = " + workers[i].Count);
                sum += workers[i].Count;
                if (workers[i].Error != null)
                {
                    hasErrors = true;
                    Console.WriteLine("  Ошибка в потоке " + (i + 1) + ": " + workers[i].Error.Message);
                }
            }

            Console.WriteLine("Итого гласных (сумма результатов потоков): " + sum);
            Console.WriteLine("Итого гласных (общий счетчик Interlocked):  " + Total);
            Console.WriteLine("Время многопоточного подсчета: " + sw.ElapsedMilliseconds + " мс");

            // Проверка: считаем те же гласные одним потоком
            sw.Restart();
            long check = CountSequential(path);
            sw.Stop();
            Console.WriteLine("Проверка одним потоком: " + check + " (время " + sw.ElapsedMilliseconds + " мс)");
            Console.WriteLine(!hasErrors && check == sum && check == Total
                ? "РЕЗУЛЬТАТ ВЕРНЫЙ: все три значения совпали."
                : "ВНИМАНИЕ: значения не совпали или были ошибки!");
        }

        // Обычный (однопоточный) подсчет - только для проверки результата
        static long CountSequential(string path)
        {
            long count = 0;
            byte[] buffer = new byte[64 * 1024];
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                int read;
                while ((read = fs.Read(buffer, 0, buffer.Length)) > 0)
                {
                    for (int i = 0; i < read; i++)
                    {
                        count += VowelTable[buffer[i]];
                    }
                }
            }
            return count;
        }

        // Создание тестового текстового файла нужного размера
        static void GenerateFile(string path, long targetBytes)
        {
            string[] words =
            {
                "apple", "orange", "banana", "computer", "thread", "process", "memory", "window",
                "system", "kernel", "queue", "audio", "evening", "universe", "привет", "мир", "поток"
            };
            Random rnd = new Random(12345);
            long written = 0;
            using (StreamWriter w = new StreamWriter(path, false, new UTF8Encoding(false)))
            {
                while (written < targetBytes)
                {
                    StringBuilder line = new StringBuilder();
                    for (int i = 0; i < 12; i++)
                    {
                        line.Append(words[rnd.Next(words.Length)]).Append(' ');
                    }
                    string text = line.ToString();
                    w.WriteLine(text);
                    written += Encoding.UTF8.GetByteCount(text) + 2;
                }
            }
        }

        // ------------------------------ ЗАДАНИЕ 2 ------------------------------
        static void Task2()
        {
            int[] data = new int[100];
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = i + 1;   // числа от 1 до 100
            }

            const int threadsCount = 4;
            int size = data.Length / threadsCount;   // 25 элементов на поток
            long[] sums = new long[threadsCount];    // каждый поток пишет в СВОЮ ячейку - гонки нет
            Thread[] threads = new Thread[threadsCount];

            for (int t = 0; t < threadsCount; t++)
            {
                int index = t;                       // копия для лямбды (иначе все потоки увидят последнее t)
                int first = index * size;
                int last = first + size - 1;

                threads[index] = new Thread(() =>
                {
                    // тело потока: никаких if, только цикл и сложение
                    long sum = 0;
                    for (int i = first; i <= last; i++)
                    {
                        sum += data[i];
                    }
                    sums[index] = sum;
                    Console.WriteLine("Поток " + (index + 1) + ": индексы " + first + "-" + last + ", сумма = " + sum);
                });
                threads[index].Start();
            }

            // основной поток ждет завершения всех
            foreach (Thread th in threads)
            {
                th.Join();
            }

            long total = 0;
            for (int i = 0; i < threadsCount; i++)
            {
                total += sums[i];
            }
            Console.WriteLine("Общая сумма всех элементов массива = " + total + " (ожидается 5050)");
        }
    }
}
