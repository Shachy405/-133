﻿// Практическая работа №3. Блокирующие переменные: lock, Monitor, Mutex, Semaphore, дедлок.
using System;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace Pr3_Locks
{
    class Program
    {
        const int ThreadsCount = 4;        // сколько потоков увеличивают счетчик
        const int Iterations = 100000;     // сколько раз каждый поток увеличивает счетчик

        static int counter;                                  // общий ресурс - счетчик
        static readonly object LockObject = new object();    // объект-замок для lock и Monitor
        static readonly Mutex CounterMutex = new Mutex();    // Mutex для шага 3

        static int inside;       // сколько потоков сейчас внутри семафора (шаг 4)
        static int maxInside;    // максимум, который мы наблюдали

        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("=== Практическая работа №3: блокировки ===");
                Console.WriteLine("1. Без синхронизации (показать ошибку - гонку потоков)");
                Console.WriteLine("2. Шаг 1: lock");
                Console.WriteLine("3. Шаг 2: Monitor.Enter / Monitor.Exit");
                Console.WriteLine("4. Шаг 3: Mutex");
                Console.WriteLine("5. Шаг 3 (по желанию): Mutex между процессами");
                Console.WriteLine("6. Шаг 4: Semaphore (не более 2 потоков одновременно)");
                Console.WriteLine("7. Шаг 5: дедлок и его исправление");
                Console.WriteLine("8. Сравнение всех вариантов по времени");
                Console.WriteLine("0. Выход");
                Console.Write("Введите номер: ");

                string choice = (Console.ReadLine() ?? "0").Trim();
                switch (choice)
                {
                    case "1": RunVariant("Без синхронизации", WorkNoSync); break;
                    case "2": RunVariant("lock", WorkLock); break;
                    case "3": RunVariant("Monitor", WorkMonitor); break;
                    case "4": RunVariant("Mutex", WorkMutex); break;
                    case "5": MutexBetweenProcesses(); break;
                    case "6": SemaphoreDemo(); break;
                    case "7": DeadlockDemo(); break;
                    case "8": CompareAll(); break;
                    case "0": return;
                    default: Console.WriteLine("Неверный номер."); break;
                }
            }
        }

        // ---------- Общий запуск: создаем потоки, ждем, печатаем итог ----------
        static void RunVariant(string title, ThreadStart work)
        {
            counter = 0;
            Thread[] threads = new Thread[ThreadsCount];

            Stopwatch sw = Stopwatch.StartNew();
            for (int i = 0; i < ThreadsCount; i++)
            {
                threads[i] = new Thread(work);
                threads[i].Start();
            }
            foreach (Thread t in threads)
            {
                t.Join();
            }
            sw.Stop();

            long expected = (long)ThreadsCount * Iterations;
            string verdict = counter == expected ? "ВЕРНО" : "ОШИБКА: часть увеличений потеряна";
            Console.WriteLine(title.PadRight(20) + " итог = " + counter + " (ожидалось " + expected + ")  " +
                              verdict + "  время " + sw.ElapsedMilliseconds + " мс");
        }

        // ---------- Варианты работы потока со счетчиком ----------

        // Нет защиты: counter++ состоит из трех действий (прочитать, прибавить, записать),
        // потоки "перебивают" друг друга, и часть увеличений теряется.
        static void WorkNoSync()
        {
            for (int i = 0; i < Iterations; i++)
            {
                counter++;
            }
        }

        // Шаг 1: lock - только один поток внутри блока в каждый момент времени
        static void WorkLock()
        {
            for (int i = 0; i < Iterations; i++)
            {
                lock (LockObject)
                {
                    counter++;
                }
            }
        }

        // Шаг 2: Monitor - то же самое "вручную". lock - это сокращенная запись именно такой конструкции.
        static void WorkMonitor()
        {
            for (int i = 0; i < Iterations; i++)
            {
                Monitor.Enter(LockObject);
                try
                {
                    counter++;
                }
                finally
                {
                    Monitor.Exit(LockObject);   // освобождаем замок даже если случилась ошибка
                }
            }
        }

        // Шаг 3: Mutex - объект операционной системы (медленнее, но может работать между процессами)
        static void WorkMutex()
        {
            for (int i = 0; i < Iterations; i++)
            {
                CounterMutex.WaitOne();
                try
                {
                    counter++;
                }
                finally
                {
                    CounterMutex.ReleaseMutex();
                }
            }
        }

        // Для сравнения: Interlocked - атомарная операция процессора, без замков
        static void WorkInterlocked()
        {
            for (int i = 0; i < Iterations; i++)
            {
                Interlocked.Increment(ref counter);
            }
        }

        // ---------- Шаг 3 (по желанию): Mutex между процессами ----------
        static void MutexBetweenProcesses()
        {
            // Имя делает Mutex общим для всех процессов пользователя на этом компьютере
            using (Mutex named = new Mutex(false, "Local\\Pr3_NamedMutex_Demo"))
            {
                Console.WriteLine("Пробуем занять именованный Mutex (ждем до 1 секунды)...");
                bool acquired = named.WaitOne(1000);
                if (!acquired)
                {
                    Console.WriteLine("Mutex занят ДРУГИМ ПРОЦЕССОМ (другой копией программы). Вот так Mutex работает между процессами.");
                    return;
                }

                try
                {
                    Console.WriteLine("Mutex занят этим процессом.");
                    Console.WriteLine("Теперь запустите ВТОРУЮ копию программы в другом окне и выберите пункт 5.");
                    Console.WriteLine("Нажмите Enter здесь, чтобы освободить Mutex.");
                    Console.ReadLine();
                }
                finally
                {
                    named.ReleaseMutex();
                    Console.WriteLine("Mutex освобожден.");
                }
            }
        }

        // ---------- Шаг 4: Semaphore ----------
        static void SemaphoreDemo()
        {
            const int workers = 6;
            inside = 0;
            maxInside = 0;

            // 2 - сколько потоков пускаем сразу, 2 - максимальное значение счетчика семафора
            using (Semaphore semaphore = new Semaphore(2, 2))
            {
                Thread[] threads = new Thread[workers];
                for (int i = 0; i < workers; i++)
                {
                    int id = i + 1;
                    threads[i] = new Thread(() =>
                    {
                        Console.WriteLine(Stamp() + "Поток " + id + " ждет входа");
                        semaphore.WaitOne();   // если внутри уже 2 потока - ждем здесь
                        try
                        {
                            int now = Interlocked.Increment(ref inside);
                            lock (LockObject)
                            {
                                if (now > maxInside)
                                {
                                    maxInside = now;
                                }
                            }
                            Console.WriteLine(Stamp() + "Поток " + id + " ВОШЕЛ (внутри сейчас: " + now + ")");
                            Thread.Sleep(1000);   // имитация работы с ресурсом
                        }
                        finally
                        {
                            Interlocked.Decrement(ref inside);
                            Console.WriteLine(Stamp() + "Поток " + id + " вышел");
                            semaphore.Release();
                        }
                    });
                    threads[i].Start();
                }

                foreach (Thread t in threads)
                {
                    t.Join();
                }
            }

            Console.WriteLine("Максимум потоков внутри одновременно: " + maxInside + " (должно быть не больше 2)");
        }

        static string Stamp()
        {
            return "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "] ";
        }

        // ---------- Шаг 5: дедлок ----------
        static void DeadlockDemo()
        {
            Console.WriteLine("--- Часть 1: потоки берут замки A и B в РАЗНОМ порядке ---");
            bool finished = RunTwoThreads(false);
            Console.WriteLine(finished
                ? "Потоки завершились (в этот раз повезло, но так быть не должно)."
                : "ДЕДЛОК: потоки не завершились за 3 секунды - каждый держит свой замок и ждет чужой.");

            Console.WriteLine();
            Console.WriteLine("--- Часть 2: исправление - ОБА потока берут замки в одном порядке (A, затем B) ---");
            finished = RunTwoThreads(true);
            Console.WriteLine(finished
                ? "Потоки завершились успешно - дедлока нет."
                : "Неожиданно: потоки зависли.");
        }

        // sameOrder = false -> поток 1 берет A затем B, поток 2 берет B затем A (ведет к дедлоку)
        // sameOrder = true  -> оба берут сначала A, затем B (безопасно)
        static bool RunTwoThreads(bool sameOrder)
        {
            // Для каждого запуска - свои замки, чтобы зависший прошлый запуск не мешал
            object lockA = new object();
            object lockB = new object();

            Thread t1 = new Thread(() =>
            {
                lock (lockA)
                {
                    Console.WriteLine("Поток 1: взял A");
                    Thread.Sleep(300);   // даем второму потоку время взять свой замок
                    Console.WriteLine("Поток 1: хочет взять B");
                    lock (lockB)
                    {
                        Console.WriteLine("Поток 1: взял A и B, работает");
                    }
                }
            });

            Thread t2 = new Thread(() =>
            {
                object first = sameOrder ? lockA : lockB;
                object second = sameOrder ? lockB : lockA;
                string firstName = sameOrder ? "A" : "B";
                string secondName = sameOrder ? "B" : "A";

                lock (first)
                {
                    Console.WriteLine("Поток 2: взял " + firstName);
                    Thread.Sleep(300);
                    Console.WriteLine("Поток 2: хочет взять " + secondName);
                    lock (second)
                    {
                        Console.WriteLine("Поток 2: взял оба замка, работает");
                    }
                }
            });

            // Фоновые потоки не мешают закрыть программу, даже если они зависли
            t1.IsBackground = true;
            t2.IsBackground = true;

            t1.Start();
            t2.Start();

            bool done1 = t1.Join(3000);   // ждем не больше 3 секунд
            bool done2 = t2.Join(3000);
            return done1 && done2;
        }

        // ---------- Сравнение всех вариантов ----------
        static void CompareAll()
        {
            Console.WriteLine("Потоков: " + ThreadsCount + ", увеличений в каждом: " + Iterations);
            RunVariant("Без синхронизации", WorkNoSync);
            RunVariant("lock", WorkLock);
            RunVariant("Monitor", WorkMonitor);
            RunVariant("Mutex", WorkMutex);
            RunVariant("Interlocked", WorkInterlocked);
        }
    }
}
