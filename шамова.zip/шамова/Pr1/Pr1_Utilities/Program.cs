﻿// Практическая работа №1. Консольная программа на C# для запуска утилит Windows.
// Программа показывает меню из 8 групп утилит; по номеру запускает выбранную утилиту.
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pr1_Utilities
{
    // Описание одной утилиты (одна строка таблицы из задания)
    class UtilityInfo
    {
        public string Group { get; }      // группа утилит
        public string Title { get; }      // название утилиты
        public string FileName { get; }   // что запускаем
        public string Arguments { get; }  // параметры командной строки
        public bool IsConsole { get; }    // true - консольная команда (вывод покажем здесь), false - окно программы
        public string Note { get; }       // пояснение, которое печатается после запуска

        public UtilityInfo(string group, string title, string fileName, string arguments, bool isConsole, string note)
        {
            Group = group;
            Title = title;
            FileName = fileName;
            Arguments = arguments;
            IsConsole = isConsole;
            Note = note;
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;

            // Рабочая папка для демонстрации (во временной папке пользователя)
            string workDir = Path.Combine(Path.GetTempPath(), "pr1_demo");
            Directory.CreateDirectory(workDir);
            string demoFile = Path.Combine(workDir, "demo.txt");
            CreateDemoFile(demoFile);

            // В тексте параметров {demo}, {cab}, {dir} заменяются на реальные пути при запуске
            UtilityInfo[] utilities =
            {
                new UtilityInfo("Интегрированные пакеты", "Управление компьютером (набор оснасток)",
                    "compmgmt.msc", "", false,
                    "Одно окно, в котором собраны диспетчер устройств, управление дисками, службы, планировщик и др."),
                new UtilityInfo("Средства диагностики", "Сведения о системе",
                    "msinfo32.exe", "", false,
                    "Показывает сведения об оборудовании, драйверах и ОС. Другие средства: dxdiag, mdsched, chkdsk."),
                new UtilityInfo("Деинсталляторы", "Программы и компоненты",
                    "appwiz.cpl", "", false,
                    "Список установленных программ с кнопкой «Удалить»."),
                new UtilityInfo("Утилиты сжатия файлов", "makecab - сжатие файла в архив CAB",
                    "cmd.exe", "/c makecab \"{demo}\" \"{cab}\"", true,
                    "Создан архив demo.cab (см. размеры ниже)."),
                new UtilityInfo("Мониторинг сбоев и восстановление работоспособности", "Просмотр событий",
                    "eventvwr.msc", "", false,
                    "Журналы ошибок и предупреждений. Рядом: perfmon /rel (монитор стабильности), rstrui (восстановление системы), sfc /scannow."),
                new UtilityInfo("Диспетчеры файлов", "Проводник Windows",
                    "explorer.exe", "\"{dir}\"", false,
                    "Открыта рабочая папка программы."),
                new UtilityInfo("Средства просмотра файлов", "Блокнот (просмотр текстового файла)",
                    "notepad.exe", "\"{demo}\"", false,
                    "Открыт файл demo.txt. Для картинок: mspaint, для консоли: type / more."),
                new UtilityInfo("Восстановление измененных и стертых файлов", "Корзина Windows",
                    "explorer.exe", "shell:RecycleBinFolder", false,
                    "Для глубокого восстановления: winfr C: D:\\Recovery /regular /n \\Users\\Имя\\Documents\\*.docx (Windows File Recovery из Microsoft Store).")
            };

            while (true)
            {
                PrintMenu(utilities);
                string input = Console.ReadLine() ?? "0";
                if (input.Trim() == "0")
                {
                    break;
                }

                int number;
                if (int.TryParse(input, out number) && number >= 1 && number <= utilities.Length)
                {
                    Run(utilities[number - 1], workDir, demoFile);
                }
                else
                {
                    Console.WriteLine("Неверный номер. Введите число от 0 до " + utilities.Length + ".");
                }
            }
        }

        static void CreateDemoFile(string path)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= 300; i++)
            {
                sb.AppendLine("Строка " + i + ": учебный файл для практической работы №1 (утилиты ОС).");
            }
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }

        static void PrintMenu(UtilityInfo[] list)
        {
            Console.WriteLine();
            Console.WriteLine("=== Запуск утилит Windows ===");
            for (int i = 0; i < list.Length; i++)
            {
                Console.WriteLine((i + 1) + ". " + list[i].Group + "  ->  " + list[i].Title);
            }
            Console.WriteLine("0. Выход");
            Console.Write("Введите номер: ");
        }

        static void Run(UtilityInfo u, string workDir, string demoFile)
        {
            string cabFile = Path.Combine(workDir, "demo.cab");
            string args = u.Arguments
                .Replace("{demo}", demoFile)
                .Replace("{cab}", cabFile)
                .Replace("{dir}", workDir);

            Console.WriteLine();
            Console.WriteLine("Группа:  " + u.Group);
            Console.WriteLine("Утилита: " + u.Title);
            Console.WriteLine("Команда: " + u.FileName + " " + args);

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = u.FileName;
                psi.Arguments = args;
                psi.WorkingDirectory = workDir;

                if (u.IsConsole)
                {
                    // Консольная команда: запускаем скрыто и выводим ее результат в нашу консоль
                    psi.UseShellExecute = false;
                    psi.RedirectStandardOutput = true;
                    psi.RedirectStandardError = true;
                    psi.CreateNoWindow = true;
                    Encoding oem = GetOemEncoding();
                    psi.StandardOutputEncoding = oem;
                    psi.StandardErrorEncoding = oem;

                    using (Process p = Process.Start(psi))
                    {
                        string output = p.StandardOutput.ReadToEnd();
                        string error = p.StandardError.ReadToEnd();
                        p.WaitForExit();
                        Console.WriteLine("--- вывод утилиты ---");
                        Console.WriteLine(output);
                        if (error.Length > 0)
                        {
                            Console.WriteLine("--- сообщения об ошибках ---");
                            Console.WriteLine(error);
                        }
                        Console.WriteLine("Код завершения: " + p.ExitCode);
                    }

                    if (File.Exists(cabFile))
                    {
                        long before = new FileInfo(demoFile).Length;
                        long after = new FileInfo(cabFile).Length;
                        Console.WriteLine("Размер demo.txt: " + before + " байт; demo.cab: " + after + " байт.");
                    }
                }
                else
                {
                    // Программа с окном: запускаем через оболочку Windows
                    psi.UseShellExecute = true;
                    Process.Start(psi);
                    Console.WriteLine("Окно утилиты запущено.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Не удалось запустить утилиту: " + ex.Message);
            }

            Console.WriteLine("Примечание: " + u.Note);
        }

        // Кодировка консольных программ Windows (OEM, для русской Windows - 866)
        static Encoding GetOemEncoding()
        {
            try
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                return Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
            }
            catch (Exception)
            {
                return Encoding.UTF8;
            }
        }
    }
}
